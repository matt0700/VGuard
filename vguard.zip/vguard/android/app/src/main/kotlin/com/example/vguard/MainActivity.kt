package com.example.vguard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
